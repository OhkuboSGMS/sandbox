from ymlc.main import update_config,write_config
